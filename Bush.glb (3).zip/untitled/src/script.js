// script.js - core game logic (no modules; uses global THREE)
(() => {
  const MODEL_PATH = 'models/'; // relative folder you will zip/upload to Tiiny
  const PLAYER_START_OFFSET = new THREE.Vector3(6,0,0); // spawn offset from lab
  const WORLD_RADIUS = 900; // half-world size (very large)
  const MAX_AGE_PER_STAGE = 60; // seconds until next growth stage

  // model filenames (must exist in models/)
  const MODEL_FILES = {
    T_REX: 'T-Rex.glb',
    DIPLO: 'Diplodocus.glb',
    STEGO: 'Stegosaurus.glb',
    SPINO: 'Dimonstrodon.glb',
    TRIKE: 'Triceratops.glb',
    VELO: 'Velociraptor.glb',
    LAB: 'High Fidelity BotLab.glb',
    MOUNTAIN: 'Mountain.glb',
    ROCK: 'Rock Large.glb',
    TREE1: 'Tree.glb',
    TREE2: 'Twisted Tree.glb',
    BUSH: 'Bush.glb',
    FENCE: 'Fence.glb' // optional
  };

  // scene setup
  let camera, scene, renderer, controls;
  let player = null;
  let loader = new THREE.GLTFLoader();
  let clock = new THREE.Clock();
  let hunger = 100, thirst = 100, hp = 100, age = 0;
  let growthStage = 0; // 0=baby,1=juvenile,2=adult,3=elder
  const growthScales = [0.6, 1.0, 1.4, 1.8];
  const bots = [];
  const plants = [];
  const corpses = [];
  const labPosition = new THREE.Vector3(0,0,0);

  // input movement
  const keys = { w:false,a:false,s:false,d:false,shift:false };
  window.addEventListener('keydown', e => {
    if (e.key === 'w') keys.w=true;
    if (e.key === 'a') keys.a=true;
    if (e.key === 's') keys.s=true;
    if (e.key === 'd') keys.d=true;
    if (e.key === 'Shift') keys.shift=true;
  });
  window.addEventListener('keyup', e => {
    if (e.key === 'w') keys.w=false;
    if (e.key === 'a') keys.a=false;
    if (e.key === 's') keys.s=false;
    if (e.key === 'd') keys.d=false;
    if (e.key === 'Shift') keys.shift=false;
  });

  // UI elements
  const ageBarEl = document.getElementById('age-bar');
  const hpBarEl = document.getElementById('hp-bar');
  const thirstBarEl = document.getElementById('thirst-bar');
  const hungerBarEl = document.getElementById('hunger-bar');
  const menuEl = document.getElementById('menu');

  // helpers
  function setWidth(el, pct) { if (el) el.style.width = `${Math.max(0, Math.min(100,pct))}%`; }

  // initialize 3D
  function initScene() {
    scene = new THREE.Scene();
    scene.background = new THREE.Color(0x87ceeb);
    camera = new THREE.PerspectiveCamera(60, window.innerWidth/window.innerHeight, 0.1, 5000);
    camera.position.set(0,8,18);

    renderer = new THREE.WebGLRenderer({ antialias:true });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.shadowMap.enabled = true;
    document.body.appendChild(renderer.domElement);

    controls = new THREE.OrbitControls(camera, renderer.domElement);
    controls.enablePan = false;
    controls.maxPolarAngle = Math.PI * 0.49;

    // lights
    const hemi = new THREE.HemisphereLight(0xffffff, 0x444444, 0.6);
    scene.add(hemi);
    const dir = new THREE.DirectionalLight(0xffffff, 0.9);
    dir.position.set(10,30,10);
    dir.castShadow = true;
    scene.add(dir);

    // big ground
    const groundMat = new THREE.MeshStandardMaterial({ color:0x2f7a2f });
    const ground = new THREE.Mesh(new THREE.PlaneGeometry(WORLD_RADIUS*2, WORLD_RADIUS*2, 16,16), groundMat);
    ground.rotation.x = -Math.PI/2;
    ground.receiveShadow = true;
    scene.add(ground);

    // mountains / rocks / lab / fences
    placeDecorations();
    spawnPlantsRandom(120);
    spawnPonds(12);
    createPerimeterFence(WORLD_RADIUS - 10);

    window.addEventListener('resize', onWindowResize);
  }

  function onWindowResize(){
    camera.aspect = window.innerWidth/window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
  }

  // place decorative models (mountains, rocks, lab)
  function placeDecorations(){
    // try to load mountain, rocks, trees; ignore if missing
    safeLoad(MODEL_FILES.MOUNTAIN, (g) => {
      for (let i=0;i<8;i++){
        const m = g.scene.clone();
        const x = Math.random()*WORLD_RADIUS - WORLD_RADIUS/2;
        const z = Math.random()*WORLD_RADIUS - WORLD_RADIUS/2;
        m.position.set(x,0,z);
        m.scale.setScalar(6 + Math.random()*8);
        scene.add(m);
      }
    });

    safeLoad(MODEL_FILES.ROCK, (g)=> {
      for (let i=0;i<20;i++){
        const r = g.scene.clone();
        r.position.set(Math.random()*WORLD_RADIUS - WORLD_RADIUS/2, 0, Math.random()*WORLD_RADIUS - WORLD_RADIUS/2);
        r.scale.setScalar(2 + Math.random()*3);
        scene.add(r);
      }
    });

    safeLoad(MODEL_FILES.LAB, (g) => {
      const lab = g.scene.clone();
      lab.position.copy(labPosition);
      lab.scale.setScalar(1.6);
      scene.add(lab);
      // Player will spawn near lab
    });

    // trees
    [MODEL_FILES.TREE1, MODEL_FILES.TREE2].forEach((tfile) => {
      safeLoad(tfile, (g) => {
        for (let i=0;i<40;i++){
          const t = g.scene.clone();
          t.position.set(Math.random()*WORLD_RADIUS - WORLD_RADIUS/2, 0, Math.random()*WORLD_RADIUS - WORLD_RADIUS/2);
          const s = 1 + Math.random()*1.6;
          t.scale.setScalar(s);
          scene.add(t);
        }
      });
    });
  }

  // helper to attempt to load glb (silently fails)
  function safeLoad(file, onSuccess){
    if(!file) return;
    loader.load(MODEL_PATH + file, (g) => onSuccess(g), undefined, () => {});
  }

  // spawn plants (bushes) and store with regen timer
  function spawnPlantsRandom(n) {
    // Try GLB bush if exists, otherwise create spheres
    let bushLoaded = false;
    loader.load(MODEL_PATH + (MODEL_FILES.BUSH || ''), (g) => {
      bushLoaded = true;
      for (let i=0;i<n;i++){
        const b = g.scene.clone();
        b.position.set(Math.random()*WORLD_RADIUS - WORLD_RADIUS/2, 0, Math.random()*WORLD_RADIUS - WORLD_RADIUS/2);
        b.scale.setScalar(0.5 + Math.random()*1.2);
        b.userData = { isPlant:true, eaten:false, respawnTimer:0 };
        scene.add(b);
        plants.push(b);
      }
    }, undefined, () => {
      // fallback spheres
      for (let i=0;i<n;i++){
        const mesh = new THREE.Mesh(new THREE.SphereGeometry(1.0,8,6), new THREE.MeshStandardMaterial({ color:0x2e8b57 }));
        mesh.position.set(Math.random()*WORLD_RADIUS - WORLD_RADIUS/2, 0.5, Math.random()*WORLD_RADIUS - WORLD_RADIUS/2);
        mesh.scale.setScalar(0.6 + Math.random()*1.4);
        mesh.userData = { isPlant:true, eaten:false, respawnTimer:0 };
        scene.add(mesh);
        plants.push(mesh);
      }
    });
  }

  // create blue circular ponds
  function spawnPonds(n){
    for (let i=0;i<n;i++){
      const r = 3 + Math.random()*6;
      const mat = new THREE.MeshBasicMaterial({ color:0x2b9aff, transparent:true, opacity:0.95 });
      const pond = new THREE.Mesh(new THREE.CircleGeometry(r,32), mat);
      pond.rotation.x = -Math.PI/2;
      pond.position.set(Math.random()*WORLD_RADIUS - WORLD_RADIUS/2, 0.02, Math.random()*WORLD_RADIUS - WORLD_RADIUS/2);
      pond.userData = { isPond:true, radius:r };
      scene.add(pond);
    }
  }

  // perimeter fence using boxes if fence model missing
  function createPerimeterFence(radius){
    // If fence model exists, attempt to tile it. Otherwise use box walls.
    safeLoad(MODEL_FILES.FENCE, (g) => {
      const segCount = 80;
      for (let i=0;i<segCount;i++){
        const ang = (i/segCount) * Math.PI*2;
        const f = g.scene.clone();
        f.position.set(Math.cos(ang)*radius, 0, Math.sin(ang)*radius);
        f.lookAt(0,0,0);
        f.scale.setScalar(3);
        scene.add(f);
      }
    });
    // fallback
    for (let i=0;i<30;i++){
      const box = new THREE.Mesh(new THREE.BoxGeometry(radius*2/30, 8, 4), new THREE.MeshStandardMaterial({ color:0x8b7f72 }));
      box.position.set(-radius + (i+0.5)*(radius*2/30), 4, -radius);
      scene.add(box);
      const box2 = box.clone(); box2.position.set(-radius + (i+0.5)*(radius*2/30), 4, radius);
      scene.add(box2);
      const box3 = new THREE.Mesh(new THREE.BoxGeometry(4,8,radius*2/30), new THREE.MeshStandardMaterial({ color:0x8b7f72 }));
      box3.position.set(-radius,4,-radius + (i+0.5)*(radius*2/30));
      scene.add(box3);
      const box4 = box3.clone(); box4.position.set(radius,4,-radius + (i+0.5)*(radius*2/30));
      scene.add(box4);
    }
  }

  // spawn AI bots using dino models
  function spawnBots(){
    const files = [MODEL_FILES.T_REX, MODEL_FILES.DIPLO, MODEL_FILES.STEGO, MODEL_FILES.SPINO, MODEL_FILES.TRIKE, MODEL_FILES.VELO];
    for (let i=0;i<10;i++){
      const f = files[i % files.length];
      loader.load(MODEL_PATH + f, (g) => {
        const b = g.scene.clone();
        b.traverse(c => { if (c.isMesh) { c.castShadow=true; c.receiveShadow=true; }});
        b.position.set(Math.random()*WORLD_RADIUS - WORLD_RADIUS/2, 0, Math.random()*WORLD_RADIUS - WORLD_RADIUS/2);
        b.scale.setScalar(0.7);
        b.userData = { hp: 80 + Math.random()*40, lastSeenPlayer:0, type: 'bot', species: f, isDead:false };
        addBotHPLabel(b);
        scene.add(b);
        bots.push(b);
      }, undefined, ()=>{});
    }
  }

  // create a simple sprite above bot showing HP
  function addBotHPLabel(bot){
    const size = 128;
    const canvas = document.createElement('canvas');
    canvas.width = size; canvas.height = 32;
    const ctx = canvas.getContext('2d');
    function drawText() {
      ctx.clearRect(0,0,canvas.width,canvas.height);
      ctx.fillStyle = 'rgba(0,0,0,0.6)';
      ctx.fillRect(0,0,canvas.width,canvas.height);
      ctx.fillStyle = 'white';
      ctx.font = '14px sans-serif';
      ctx.fillText('HP: ' + Math.floor(bot.userData.hp || 0), 8, 20);
    }
    drawText();
    const tex = new THREE.CanvasTexture(canvas);
    const mat = new THREE.SpriteMaterial({ map: tex, depthTest:false });
    const spr = new THREE.Sprite(mat);
    spr.scale.set(6,1.5,1);
    spr.position.set(0, 5, 0);
    bot.add(spr);
    bot.userData.hpSprite = { sprite: spr, canvas: canvas, ctx: ctx, tex: tex, redraw: drawText };
  }

  // update bot HP labels
  function updateBotLabels(){
    bots.forEach(b => {
      if (b.userData && b.userData.hpSprite){
        b.userData.hpSprite.ctx.clearRect(0,0,b.userData.hpSprite.canvas.width, b.userData.hpSprite.canvas.height);
        b.userData.hpSprite.ctx.fillStyle = 'rgba(0,0,0,0.6)';
        b.userData.hpSprite.ctx.fillRect(0,0,b.userData.hpSprite.canvas.width, b.userData.hpSprite.canvas.height);
        b.userData.hpSprite.ctx.fillStyle = 'white';
        b.userData.hpSprite.ctx.font = '14px sans-serif';
        b.userData.hpSprite.ctx.fillText('HP: ' + Math.max(0, Math.floor(b.userData.hp || 0)), 8, 20);
        b.userData.hpSprite.tex.needsUpdate = true;
      }
    });
  }

  // player spawn near lab
  function spawnPlayerFromFile(filename){
    return new Promise((resolve, reject) => {
      loader.load(MODEL_PATH + filename, (g) => {
        player = g.scene.clone();
        player.traverse(c => { if (c.isMesh) { c.castShadow=true; c.receiveShadow=true; }});
        player.position.copy(labPosition).add(PLAYER_START_OFFSET);
        player.scale.setScalar(growthScales[growthStage]);
        player.userData = { species: filename, isCarnivore: isCarnivore(filename) };
        scene.add(player);
        controls.target.copy(player.position);
        resolve(player);
      }, undefined, (err) => reject(err));
    });
  }

  function isCarnivore(filename){
    const carn = ['T-Rex.glb','Velociraptor.glb','Dimonstrodon.glb'];
    return carn.includes(filename);
  }

  // eat corpse: player or bot standing near corpse of opposite species
  function tryEatCorpse(actor){
    for (let i=0;i<corpses.length;i++){
      const c = corpses[i];
      if (!c.userData.eaten && actor.position.distanceTo(c.position) < 2.5){
        // eat and restore
        if (actor.userData.isCarnivore){
          actor.userData.isPlayer? (hunger = Math.min(100, hunger + 40)) : (actor.userData.hp += 20);
          c.userData.eaten = true;
          scene.remove(c);
          corpses.splice(i,1);
          return true;
        }
      }
    }
    return false;
  }

  // if your player dies: rotate to lay down and convert to corpse (other carnivores can eat)
  function makeCorpseFrom(obj){
    obj.userData.isDead = true;
    obj.userData.isCorpse = true;
    // flatten and rotate
    obj.rotation.x = -Math.PI/2.0;
    corpses.push(obj);
  }

  // main update loop
  function animate(){
    requestAnimationFrame(animate);
    const dt = Math.min(0.2, clock.getDelta());

    if (player){
      // needs
 drain
      hunger = Math.max(0, hunger - dt * 0.8);
      thirst = Math.max(0, thirst - dt * 0.9);
      // penalties
      if (hunger <= 0 || thirst <= 0) hp = Math.max(0, hp - dt * 10);

      // age progression
      age += dt;
      setWidth(ageBarEl, (age / MAX_AGE_PER_STAGE) * 100);

      // growth
      if (age >= MAX_AGE_PER_STAGE){
        age = 0;
        growthStage = Math.min(3, growthStage + 1);
        if (player) player.scale.multiplyScalar(1.25);
        // increase stats on growth
        hp = Math.min(100, hp + 20);
        hunger = Math.min(100, hunger + 10);
        thirst = Math.min(100, thirst + 10);
      }

      // movement - basic first-personish third person based on camera forward
      const forward = new THREE.Vector3();
      camera.getWorldDirection(forward);
      forward.y = 0; forward.normalize();
      const right = new THREE.Vector3().crossVectors(new THREE.Vector3(0,1,0), forward).normalize();
      let speed = keys.shift ? 10 : 5;
      if (keys.w) player.position.addScaledVector(forward, dt * speed);
      if (keys.s) player.position.addScaledVector(forward, -dt * speed);
      if (keys.a) player.position.addScaledVector(right, -dt * speed);
      if (keys.d) player.position.addScaledVector(right, dt * speed);
      controls.target.copy(player.position);
      camera.position.lerp(new THREE.Vector3(player.position.x + 0, player.position.y + 6, player.position.z + 12), 0.06);

      // try to drink when on pond (standing over pond)
      const ponds = scene.children.filter(c => c.userData && c.userData.isPond);
      for (let p of ponds){
        const d = p.position.distanceTo(player.position);
        if (d < (p.userData.radius || 3)){
          thirst = Math.min(100, thirst + dt * 40); // drink fast
        }
      }

      // eating plants for herbivores
      if (!player.userData.isCarnivore){
        // try eat plant nearby
        for (let pl of plants){
          if (!pl.userData.eaten && pl.position.distanceTo(player.position) < 2.2){
            pl.userData.eaten = true;
            scene.remove(pl);
            pl.userData.respawnTimer = 30 + Math.random()*40;
            plants.splice(plants.indexOf(pl),1);
            hunger = Math.min(100, hunger + 35);
            break;
          }
        }
      } else {
        // carnivore tries to eat corpses automatically
        tryEatCorpse(player);
      }

      // death -> corpse
      if (hp <= 0 && player && !player.userData.isDead){
        makeCorpseFrom(player);
        // create a new 'dead body' object so player respawns as baby near lab
        setTimeout(() => {
          // respawn player as baby at lab after 3 seconds
          // clone species
          const speciesFile = player.userData.species;
          scene.remove(player); player = null;
          setTimeout(async ()=>{
            await spawnPlayerAtLab(speciesFile);
            hunger = 100; thirst = 100; hp = 100; age = 0; growthStage = 0;
          }, 500);
        }, 1000);
      }
    }

    // update bots
    updateBots(dt);
    // update plants regrow
    handlePlantRegrow(dt);
    // update bot HP labels
    updateBotLabels();
    // update bottom UI
    setWidth(hpBarEl, hp);
    setWidth(thirstBarEl, thirst);
    setWidth(hungerBarEl, hunger);

    renderer.render(scene, camera);
  }

  // spawn player at lab helper
  function spawnPlayerAtLab(filename){
    return new Promise((resolve) => {
      loader.load(MODEL_PATH + filename, (g) => {
        const p = g.scene.clone();
        p.traverse(c => { if (c.isMesh) { c.castShadow=true; c.receiveShadow=true; }});
        p.position.copy(labPosition).add(PLAYER_START_OFFSET);
        p.scale.setScalar(growthScales[growthStage]);
        p.userData = { species: filename, isCarnivore: isCarnivore(filename), isPlayer:true };
        scene.add(p);
        player = p;
        resolve(p);
      }, undefined, ()=>{ resolve(null); });
    });
  }

  // update bots behaviour
  function updateBots(dt){
    for (let b of bots){
      if (b.userData.isDead) continue;
      // wander
      if (!b.userData.wanderTarget || Math.random() < 0.012){
        b.userData.wanderTarget = new THREE.Vector3(Math.random()*WORLD_RADIUS - WORLD_RADIUS/2, 0, Math.random()*WORLD_RADIUS - WORLD_RADIUS/2);
      }
      const dir = b.userData.wanderTarget.clone().sub(b.position);
      if (dir.length() > 0.6){
        dir.normalize();
        b.position.addScaledVector(dir, dt * (0.5 + Math.random()*0.8));
        b.lookAt(b.position.x + dir.x, b.position.y, b.position.z + dir.z);
      }

      // simple aggression: if player is near and bot carnivore, attack
      if (player && b.position.distanceTo(player.position) < 6){
        if (isCarnivore(b.userData.species)){
          // move toward player faster and damage occasionally
          const toPlayer = player.position.clone().sub(b.position).normalize();
          b.position.addScaledVector(toPlayer, dt * 1.6);
          if (Math.random() < 0.02) {
            hp = Math.max(0, hp - (3 + Math.random()*6));
          }
        } else {
          // herbivore flees slightly
          const away = b.position.clone().sub(player.position).normalize();
          b.position.addScaledVector(away, dt * 1.2);
        }
      }

      // bots can eat plants if herbivore
      if (!isCarnivore(b.userData.species)){
        for (let i=plants.length-1;i>=0;i--){
          const pl = plants[i];
          if (!pl.userData.eaten && pl.position.distanceTo(b.position) < 1.8){
            // eat
            pl.userData.eaten = true;
            scene.remove(pl);
            pl.userData.respawnTimer = 25 + Math.random()*35;
            plants.splice(i,1);
            b.userData.hp = Math.min(100, (b.userData.hp || 50) + 30);
            break;
          }
        }
      } else {
        // carnivores try to eat corpses
        for (let i=corpses.length-1;i>=0;i--){
          const c = corpses[i];
          if (!c.userData.eaten && c.position.distanceTo(b.position) < 2.2){
            c.userData.eaten = true;
            scene.remove(c);
            corpses.splice(i,1);
            b.userData.hp = Math.min(100, b.userData.hp + 40);
            break;
          }
        }
      }

      // bot death
      if (b.userData.hp <= 0 && !b.userData.isDead){
        b.userData.isDead = true;
        // lay down
        b.rotation.x = -Math.PI/2;
        corpses.push(b);
      }
    }
  }

  // plants regrow over time: we use a simple timer array to re-add plants
  function handlePlantRegrow(dt){
    // spawn small new plants occasionally to refill array if count low
    if (plants.length < 90 && Math.random() < 0.02){
      const mesh = new THREE.Mesh(new THREE.SphereGeometry(1.0,8,6), new THREE.MeshStandardMaterial({color:0x2e8b57}));
      mesh.position.set(Math.random()*WORLD_RADIUS - WORLD_RADIUS/2, 0.5, Math.random()*WORLD_RADIUS - WORLD_RADIUS/2);
      mesh.scale.setScalar(0.6 + Math.random()*1.4);
      mesh.userData = { isPlant:true, eaten:false, respawnTimer:0 };
      scene.add(mesh);
      plants.push(mesh);
    }
  }

  // menu click wiring
  function wireMenu(){
    menuEl.querySelectorAll('button[data-file]').forEach(b => {
      b.addEventListener('click', async () => {
        const file = b.getAttribute('data-file');
        // hide menu
        menuEl.style.display = 'none';
        // init scene & spawn
        initScene();
        await spawnPlayerAtLab(file);
        spawnBots();
        animate();
      });
    });
  }

  // start
  wireMenu();
})();
